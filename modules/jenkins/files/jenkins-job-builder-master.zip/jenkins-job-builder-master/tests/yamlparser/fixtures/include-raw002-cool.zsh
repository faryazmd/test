#!/bin/zsh
echo "Doing somethin cool with zsh"
