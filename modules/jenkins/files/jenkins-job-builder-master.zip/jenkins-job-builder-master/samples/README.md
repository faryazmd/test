# Jenkins Job Builder Examples #

Jenkins Job Builder includes many tests to demonstrate the use of Jenkins
Job Builder.  All of the tests are in the 'tests' folder.  It can be used
as a starting point for new projects.  The tests also serve as JJB docs.

Please look in the tests folder for examples of how to define yaml files
for use with JJB.  Most of the test examples are snippets of yaml, for a
more complete example look at the tests in the 'tests/yamlparser' folder.
